#include "Graph.h"

/*
* Dijkstra最短路径。
* 即，统计图中"顶点vs"到其它各个顶点的最短路径。
*
* 参数说明：
*       vs -- 起始顶点(start vertex)。即计算"顶点vs"到其它顶点的最短路径。
*     prev -- 前驱顶点数组。即，prev[i]的值是"顶点vs"到"顶点i"的最短路径所经历的全部顶点中，位于"顶点i"之前的那个顶点。
*     dist -- 长度数组。即，dist[i]是"顶点vs"到"顶点i"的最短路径的长度。
*/
void dijkstra(AdjMatrix& unitPay, int vs, vector<int>& prev, vector<int>& dist)
{
	int i, j, k;
	int min;
	int tmp;
	const int vexNum = unitPay.size();
	vector<int> flag(vexNum, 0);      // flag[i]=1表示"顶点vs"到"顶点i"的最短路径已成功获取。
	
						// 初始化
	for (i = 0; i < vexNum; i++)
	{
		dist[i] = unitPay[vs][i]; // 顶点i的最短路径为"顶点vs"到"顶点i"的权。
	}

	// 对"顶点vs"自身进行初始化
	flag[vs] = 1;
	dist[vs] = 0;

	// 遍历mVexNum-1次；每次找出一个顶点的最短路径。
	for (i = 1; i < vexNum; i++)
	{
		// 寻找当前最小的路径；
		// 即，在未获取最短路径的顶点中，找到离vs最近的顶点(k)。
		min = INF;
		for (j = 0; j < vexNum; j++)
		{
			if (flag[j] == 0 && dist[j]<min)
			{
				min = dist[j];
				k = j;
			}
		}
		// 标记"顶点k"为已经获取到最短路径
		flag[k] = 1;

		// 修正当前最短路径和前驱顶点
		// 即，当已经"顶点k的最短路径"之后，更新"未获取最短路径的顶点的最短路径和前驱顶点"。
		for (j = 0; j < vexNum; j++)
		{
			tmp = (unitPay[k][j] == INF ? INF : (min + unitPay[k][j]));
			if (flag[j] == 0 && (tmp  < dist[j]))
			{
				dist[j] = tmp;
				prev[j] = k;
			}
		}
	}

	// 打印dijkstra最短路径的结果
	cout << "dijkstra(" << vs << "): " << endl;
	for (i = 0; i < vexNum; i++)
		cout << "  shortest(" << vs << ", " << i << ")=" << dist[i] << endl;
}