#include <list>

#include "core.h"
#include "Graph.h"

using namespace std;

void computeShortestPaths(Graph& graph)
{
	vector<int> prev(graph.netNum, 0);
	vector<int> dist(graph.netNum, 0);
	dijkstra(*graph.unitPay, 0, prev, dist);
}