#include "SNode.h"
class CNode{
public:

	int ID;
	SNode server;
	int demand;

	CNode(int id,int demand){
		this->ID = id;
		this->demand = demand;
	}
	int getID(){
		return this->ID;
	}
	int compareTo(CNode c){
		if(this->ID<c.getID())
		  return -1;
		else if(this->ID>c.getID())
		  return 1;
		return 0;
	}
};
