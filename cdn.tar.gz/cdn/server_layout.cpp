#include <list>

#include "Graph.h"

using namespace std;

list<int> initialServerLocation(Graph& graph)
{
  return list<int>();
}