#include <list>

#include "Graph.h"

using namespace std;

vector<int> initialServerLocation(Graph& graph)
{
//  return vector<int>{ 0, 1, 2, 17, 13, 33, 15 };
  return vector<int>{ 0, 1 };
}