#pragma once

#include "Graph.h"

list<int> initialServerLocation(Graph& graph);

void computeShortestPaths(Graph& graph);

void dijkstra(AdjMatrix& unitPay, int vs, vector<int>& prev, vector<int>& dist);